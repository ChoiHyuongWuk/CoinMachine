package com.choimon.coinmachine;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class loginActivity {
    private Button sign_up; // 회원가입 버튼
    private EditText id_Input; // 아이디 입력
    private EditText Pass_Input; // 비밀번호 입력
    private TextView id_Seach; //아이디 찾기
    private TextView Pass_Seach; //비밀번호 찾기

    private final void login_action() {

    }
}
